import ManagerA
import ManagerB

if __name__ == "__main__":
    ManagerA.main()
    ManagerB.main()
